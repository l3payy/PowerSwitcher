using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: System.Reflection.AssemblyTitle("PowerSwitcher Alt+Q")]
[assembly: System.Reflection.AssemblyVersion("1.0.0.0")]
[assembly: System.Reflection.AssemblyFileVersion("1.0.0.0")]

static class Native
{
    public const uint ACCESS_SCHEME = 16;
    public const uint ERROR_SUCCESS = 0;
    public const uint ERROR_NO_MORE_ITEMS = 259;

    [DllImport("powrprof.dll")]
    public static extern uint PowerEnumerate(
        IntPtr RootPowerKey, IntPtr SchemeGuid, IntPtr SubGroupOfPowerSettingsGuid,
        uint AccessFlags, uint Index, ref Guid Buffer, ref uint BufferSize);

    [DllImport("powrprof.dll")]
    public static extern uint PowerGetActiveScheme(IntPtr UserRootPowerKey, out IntPtr ActivePolicyGuid);

    [DllImport("powrprof.dll")]
    public static extern uint PowerSetActiveScheme(IntPtr UserRootPowerKey, ref Guid SchemeGuid);

    [DllImport("powrprof.dll", CharSet = CharSet.Unicode)]
    public static extern uint PowerReadFriendlyName(
        IntPtr RootPowerKey, ref Guid SchemeGuid, IntPtr SubGroupOfPowerSettingsGuid,
        IntPtr PowerSettingGuid, IntPtr Buffer, ref uint BufferSize);

    [DllImport("kernel32.dll")]
    public static extern IntPtr LocalFree(IntPtr hMem);

    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    [DllImport("user32.dll")]
    public static extern bool DestroyIcon(IntPtr hIcon);
}

public class PowerScheme
{
    public Guid Id;
    public string Name;
    public PowerScheme(Guid id, string name) { Id = id; Name = name; }
}

static class PowerApi
{
    public static List<PowerScheme> GetSchemes()
    {
        List<PowerScheme> list = new List<PowerScheme>();
        for (uint i = 0; i < 64; i++)
        {
            Guid guid = Guid.Empty;
            uint size = (uint)Marshal.SizeOf(typeof(Guid));
            uint res = Native.PowerEnumerate(IntPtr.Zero, IntPtr.Zero, IntPtr.Zero,
                Native.ACCESS_SCHEME, i, ref guid, ref size);
            if (res == Native.ERROR_NO_MORE_ITEMS)
                break;
            if (res != Native.ERROR_SUCCESS)
                continue;
            string name = ReadFriendlyName(guid);
            if (string.IsNullOrEmpty(name))
                name = guid.ToString();
            list.Add(new PowerScheme(guid, name));
        }
        return list;
    }

    public static string ReadFriendlyName(Guid scheme)
    {
        try
        {
            Guid g = scheme;
            uint size = 0;
            Native.PowerReadFriendlyName(IntPtr.Zero, ref g,
                IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, ref size);
            if (size == 0)
                size = 512;
            else if (size > 4096)
                size = 4096;
            IntPtr buf = Marshal.AllocHGlobal((int)size);
            try
            {
                uint res = Native.PowerReadFriendlyName(IntPtr.Zero, ref g,
                    IntPtr.Zero, IntPtr.Zero, buf, ref size);
                if (res != Native.ERROR_SUCCESS)
                    return null;
                string s = Marshal.PtrToStringUni(buf);
                if (s != null)
                {
                    int z = s.IndexOf('\0');
                    if (z >= 0)
                        s = s.Substring(0, z);
                }
                return s;
            }
            finally
            {
                Marshal.FreeHGlobal(buf);
            }
        }
        catch { return null; }
    }

    public static Guid GetActive()
    {
        IntPtr p = IntPtr.Zero;
        try
        {
            uint res = Native.PowerGetActiveScheme(IntPtr.Zero, out p);
            if (res != Native.ERROR_SUCCESS || p == IntPtr.Zero)
                return Guid.Empty;
            // struct GUID layout = Guid
            object o = Marshal.PtrToStructure(p, typeof(Guid));
            return (Guid)o;
        }
        finally
        {
            if (p != IntPtr.Zero)
                Native.LocalFree(p);
        }
    }

    public static uint SetActive(Guid scheme)
    {
        Guid g = scheme;
        return Native.PowerSetActiveScheme(IntPtr.Zero, ref g);
    }

    public static bool IsAdmin()
    {
        try
        {
            WindowsIdentity id = WindowsIdentity.GetCurrent();
            WindowsPrincipal p = new WindowsPrincipal(id);
            return p.IsInRole(WindowsBuiltInRole.Administrator);
        }
        catch { return false; }
    }
}

class OsdForm : Form
{
    private System.Windows.Forms.Timer timer;
    private Label label;
    private Label sub;
    private Font fontTitle;
    private Font fontSub;

    // OSD не должен забирать фокус (иначе свернёт игру/видео)
    protected override bool ShowWithoutActivation { get { return true; } }

    protected override CreateParams CreateParams
    {
        get
        {
            CreateParams cp = base.CreateParams;
            cp.ExStyle |= 0x08000000 /* WS_EX_NOACTIVATE */ | 0x80 /* WS_EX_TOOLWINDOW */;
            return cp;
        }
    }

    public OsdForm(string text, string subtext)
    {
        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        TopMost = true;
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(28, 28, 28);
        Opacity = 0.93;
        Width = 520;
        Height = 130;

        label = new Label();
        label.Dock = DockStyle.Fill;
        label.Padding = new Padding(0, 18, 0, 0);
        label.Text = text;
        label.ForeColor = Color.White;
        label.BackColor = Color.Transparent;
        label.TextAlign = ContentAlignment.MiddleCenter;
        label.AutoEllipsis = true;
        fontTitle = new Font("Segoe UI", 16, FontStyle.Bold);
        label.Font = fontTitle;
        Controls.Add(label);

        sub = new Label();
        sub.Dock = DockStyle.Bottom;
        sub.Height = 34;
        sub.Text = subtext;
        sub.ForeColor = Color.FromArgb(170, 170, 170);
        sub.BackColor = Color.Transparent;
        sub.TextAlign = ContentAlignment.TopCenter;
        fontSub = new Font("Segoe UI", 9, FontStyle.Regular);
        sub.Font = fontSub;
        Controls.Add(sub);

        timer = new System.Windows.Forms.Timer();
        timer.Interval = 2000;
        timer.Tick += delegate(object s, EventArgs e)
        {
            timer.Stop();
            Close();
        };
        timer.Start();

        Click += delegate(object s, EventArgs e) { Close(); };
        label.Click += delegate(object s, EventArgs e) { Close(); };
        sub.Click += delegate(object s, EventArgs e) { Close(); };
    }

    public void UpdateText(string text, string subtext)
    {
        label.Text = text;
        sub.Text = subtext;
        timer.Stop();
        timer.Start();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            try { if (timer != null) { timer.Stop(); timer.Dispose(); } }
            catch { }
            try { if (fontTitle != null) fontTitle.Dispose(); }
            catch { }
            try { if (fontSub != null) fontSub.Dispose(); }
            catch { }
        }
        base.Dispose(disposing);
    }
}

class MainForm : Form
{
    const int HOTKEY_ID = 1;
    const uint MOD_ALT = 0x0001;
    const uint MOD_NOREPEAT = 0x4000;
    const uint VK_Q = 0x51;
    const int WM_HOTKEY = 0x0312;

    private bool handleInitDone;
    private NotifyIcon tray;
    private ContextMenuStrip menu;
    private ToolStripMenuItem currentItem;
    private ToolStripMenuItem autostartItem;
    private OsdForm osd;

    public MainForm()
    {
        ShowInTaskbar = false;
        Visible = false;

        menu = new ContextMenuStrip();
        currentItem = new ToolStripMenuItem("...");
        currentItem.Enabled = false;
        menu.Items.Add(currentItem);
        menu.Items.Add(new ToolStripSeparator());
        ToolStripMenuItem nextItem = new ToolStripMenuItem("Переключить (Alt+Q)");
        nextItem.Click += delegate(object s, EventArgs e) { CyclePowerScheme(); };
        menu.Items.Add(nextItem);
        ToolStripMenuItem listItem = new ToolStripMenuItem("Показать схемы");
        listItem.Click += delegate(object s, EventArgs e) { ShowSchemes(); };
        menu.Items.Add(listItem);
        autostartItem = new ToolStripMenuItem("Автозагрузка");
        autostartItem.Click += delegate(object s, EventArgs e) { ToggleAutostart(); };
        menu.Items.Add(autostartItem);
        ToolStripMenuItem exitItem = new ToolStripMenuItem("Выход");
        exitItem.Click += delegate(object s, EventArgs e) { CloseApp(); };
        menu.Items.Add(exitItem);
        // актуальная схема на момент открытия меню, а не только после переключения
        menu.Opening += delegate(object s, System.ComponentModel.CancelEventArgs e) { RefreshCurrentMenu(); };

        tray = new NotifyIcon();
        tray.Text = "PowerSwitcher (Alt+Q)";
        tray.Icon = CreateTrayIcon();
        tray.ContextMenuStrip = menu;
        tray.Visible = true;
        tray.DoubleClick += delegate(object s, EventArgs e) { CyclePowerScheme(); };

        // Форма никогда не показывается (см. SetVisibleCore), поэтому создаём
        // handle заранее: хоткей в OnHandleCreated привязывается именно к нему.
        IntPtr dummy = Handle;
    }

    protected override void SetVisibleCore(bool value)
    {
        base.SetVisibleCore(false);
    }

    // Простая своя иконка (молния), без внешних файлов.
    // SystemIcons.Shield убрали: он ассоциируется с UAC и вводит в заблуждение.
    private static Icon CreateTrayIcon()
    {
        try
        {
            Bitmap bmp = new Bitmap(32, 32);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.Transparent);
                using (SolidBrush bg = new SolidBrush(Color.FromArgb(45, 45, 45)))
                {
                    g.FillRectangle(bg, 0, 0, 32, 32);
                }
                Point[] bolt = new Point[] {
                    new Point(19, 2), new Point(10, 18), new Point(15, 18),
                    new Point(13, 30), new Point(23, 13), new Point(17, 13)
                };
                using (SolidBrush y = new SolidBrush(Color.FromArgb(255, 200, 40)))
                {
                    g.FillPolygon(y, bolt);
                }
            }
            IntPtr h = bmp.GetHicon();
            try
            {
                Icon tmp = Icon.FromHandle(h);
                Icon clone = (Icon)tmp.Clone();
                return clone;
            }
            finally
            {
                Native.DestroyIcon(h);
                bmp.Dispose();
            }
        }
        catch
        {
            return SystemIcons.Application;
        }
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        // MOD_NOREPEAT: без него удерживаемый Alt+Q шлёт WM_HOTKEY автоповтором
        bool ok = Native.RegisterHotKey(Handle, HOTKEY_ID, MOD_ALT | MOD_NOREPEAT, VK_Q);
        if (!ok)
        {
            MessageBox.Show("Не удалось зарегистрировать Alt+Q. Возможно, хоткей уже занят.",
                "PowerSwitcher", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        if (!handleInitDone)
        {
            handleInitDone = true;
            RefreshCurrentMenu();
            UpdateAutostartMenu();
            if (!PowerApi.IsAdmin())
            {
                tray.ShowBalloonTip(5000, "PowerSwitcher",
                    "Запущено без прав администратора. Если переключение не сработает — запустите от имени администратора или через планировщик.",
                    ToolTipIcon.Warning);
            }
        }
    }

    protected override void OnHandleDestroyed(EventArgs e)
    {
        try { Native.UnregisterHotKey(Handle, HOTKEY_ID); }
        catch { }
        base.OnHandleDestroyed(e);
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == WM_HOTKEY && m.WParam.ToInt32() == HOTKEY_ID)
        {
            CyclePowerScheme();
            return;
        }
        base.WndProc(ref m);
    }

    private void RefreshCurrentMenu()
    {
        try
        {
            Guid active = PowerApi.GetActive();
            List<PowerScheme> schemes = PowerApi.GetSchemes();
            string name = active.ToString();
            foreach (PowerScheme s in schemes)
            {
                if (s.Id == active) { name = s.Name; break; }
            }
            currentItem.Text = "Текущая: " + name;
            // Лимит NotifyIcon.Text — 63 символа, сеттер бросает исключение.
            // Поэтому обрезаем ДО присваивания, а не после.
            string tip = "PowerSwitcher: " + name;
            tray.Text = (tip.Length > 63) ? tip.Substring(0, 63) : tip;
        }
        catch { }
    }

    private void ShowOsd(string main, string subtext)
    {
        try
        {
            if (osd != null && !osd.IsDisposed)
            {
                osd.UpdateText(main, subtext);
                return;
            }
        }
        catch { }
        // Без Activate()/BringToFront: окно NOACTIVATE+TopMost само встанет
        // поверх, не отбирая фокус у игры/видео.
        osd = new OsdForm(main, subtext);
        osd.Show();
    }

    public void CyclePowerScheme()
    {
        try
        {
            List<PowerScheme> schemes = PowerApi.GetSchemes();
            if (schemes.Count == 0)
            {
                ShowOsd("Схемы не найдены", "PowerSwitcher");
                return;
            }
            Guid active = PowerApi.GetActive();
            int idx = -1;
            for (int i = 0; i < schemes.Count; i++)
            {
                if (schemes[i].Id == active) { idx = i; break; }
            }
            int nextIdx = (idx + 1) % schemes.Count;
            PowerScheme next = schemes[nextIdx];
            uint res = PowerApi.SetActive(next.Id);
            if (res == 0)
            {
                ShowOsd(next.Name, string.Format("{0}/{1}  •  Alt+Q — следующая схема", nextIdx + 1, schemes.Count));
            }
            else if (res == 5)
            {
                ShowOsd("Нужны права администратора",
                    "Запустите .exe от имени администратора");
                tray.ShowBalloonTip(4000, "PowerSwitcher",
                    "Отказано в доступе (код 5). Нужен запуск от администратора.",
                    ToolTipIcon.Error);
            }
            else
            {
                // fallback через powercfg
                bool ok = TryPowerCfg(next.Id);
                if (ok)
                    ShowOsd(next.Name, string.Format("{0}/{1}  •  Alt+Q — следующая схема", nextIdx + 1, schemes.Count));
                else
                    ShowOsd("Ошибка переключения: " + res, next.Name);
            }
            RefreshCurrentMenu();
        }
        catch (Exception ex)
        {
            ShowOsd("Ошибка: " + ex.Message, "PowerSwitcher");
        }
    }

    private bool TryPowerCfg(Guid id)
    {
        try
        {
            // Полный путь: процесс может быть elevated, ищем powercfg только в System32
            string exe = System.IO.Path.Combine(System.Environment.SystemDirectory, "powercfg.exe");
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = exe;
            psi.Arguments = "/SETACTIVE " + id.ToString();
            psi.CreateNoWindow = true;
            psi.UseShellExecute = false;
            psi.WindowStyle = ProcessWindowStyle.Hidden;
            using (Process p = Process.Start(psi))
            {
                if (p == null)
                    return false;
                if (!p.WaitForExit(5000))
                {
                    try { p.Kill(); }
                    catch { }
                    return false;
                }
                try { return p.ExitCode == 0; }
                catch { return false; }
            }
        }
        catch { return false; }
    }

    private void ShowSchemes()
    {
        try
        {
            List<PowerScheme> schemes = PowerApi.GetSchemes();
            Guid active = PowerApi.GetActive();
            string msg = "";
            for (int i = 0; i < schemes.Count; i++)
            {
                string mark = (schemes[i].Id == active) ? " * — активна" : "";
                msg += string.Format("{0}. {1}{2}\r\n{3}\r\n\r\n", i + 1, schemes[i].Name, mark, schemes[i].Id);
            }
            MessageBox.Show(msg, "Схемы электропитания", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "PowerSwitcher");
        }
    }

    private string AutostartKey()
    {
        return "PowerSwitcherAltQ";
    }

    private bool IsAutostartOn()
    {
        try
        {
            RegistryKey k = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", false);
            if (k == null) return false;
            object v = k.GetValue(AutostartKey(), null);
            k.Close();
            if (v == null) return false;
            string s = v.ToString();
            return s.IndexOf(Application.ExecutablePath, System.StringComparison.OrdinalIgnoreCase) >= 0;
        }
        catch { return false; }
    }

    private void UpdateAutostartMenu()
    {
        autostartItem.Checked = IsAutostartOn();
    }

    private void ToggleAutostart()
    {
        try
        {
            RegistryKey k = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);
            if (k == null) return;
            if (IsAutostartOn())
                k.DeleteValue(AutostartKey(), false);
            else
                k.SetValue(AutostartKey(), "\"" + Application.ExecutablePath + "\"");
            k.Close();
            UpdateAutostartMenu();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Автозагрузка: " + ex.Message, "PowerSwitcher");
        }
    }

    private void CloseApp()
    {
        try
        {
            if (osd != null && !osd.IsDisposed)
                osd.Close();
        }
        catch { }
        tray.Visible = false;
        try { Native.UnregisterHotKey(Handle, HOTKEY_ID); }
        catch { }
        Application.Exit();
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        try { Native.UnregisterHotKey(Handle, HOTKEY_ID); }
        catch { }
        if (tray != null)
            tray.Visible = false;
        base.OnFormClosing(e);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            try { if (osd != null && !osd.IsDisposed) osd.Dispose(); }
            catch { }
            try { if (tray != null) { tray.Visible = false; tray.Dispose(); } }
            catch { }
            try { if (menu != null) menu.Dispose(); }
            catch { }
        }
        base.Dispose(disposing);
    }
}

static class Program
{
    [STAThread]
    static int Main(string[] args)
    {
        bool list = false;
        bool next = false;
        foreach (string a in args)
        {
            string s = a.ToLowerInvariant();
            if (s == "/list" || s == "-list" || s == "--list") list = true;
            if (s == "/next" || s == "-next" || s == "--next") next = true;
        }

        if (list)
        {
            // консольный режим для проверки
            bool attached = false;
            try
            {
                attached = AttachConsole(ATTACH_PARENT_PROCESS);
                if (!attached)
                    attached = AllocConsole();
                try { System.Console.OutputEncoding = System.Text.Encoding.UTF8; }
                catch { }
                List<PowerScheme> schemes = PowerApi.GetSchemes();
                Guid active = PowerApi.GetActive();
                Console.WriteLine("Schemes:");
                foreach (PowerScheme sc in schemes)
                {
                    string mark = (sc.Id == active) ? " * active" : "";
                    Console.WriteLine(sc.Id.ToString() + "  " + sc.Name + mark);
                }
                Console.WriteLine("Active: " + active.ToString());
                Console.WriteLine("Admin: " + PowerApi.IsAdmin().ToString());
                return 0;
            }
            catch (Exception ex)
            {
                try { Console.WriteLine("Error: " + ex.Message); } catch { }
                return 1;
            }
            finally
            {
                try { if (attached) FreeConsole(); }
                catch { }
            }
        }

        if (next)
        {
            // тихий режим без мьютекса и без окон — чтобы не висеть если GUI уже запущен.
            // Код выхода = код PowerSetActiveScheme (0 = ок), для использования в скриптах.
            try
            {
                List<PowerScheme> schemes = PowerApi.GetSchemes();
                if (schemes.Count == 0)
                    return 1;
                Guid active = PowerApi.GetActive();
                int idx = -1;
                for (int i = 0; i < schemes.Count; i++)
                    if (schemes[i].Id == active) { idx = i; break; }
                int ni = (idx + 1) % schemes.Count;
                uint res = PowerApi.SetActive(schemes[ni].Id);
                return (int)res;
            }
            catch { return 1; }
        }

        bool createdNew = true;
        Mutex m = null;
        try
        {
            m = new Mutex(true, "PowerSwitcherAltQ_Mutex", out createdNew);
        }
        catch (System.UnauthorizedAccessException)
        {
            // Первый экземпляр запущен с другими правами (например, elevated
            // из планировщика) — объект мьютекса не отдают. Это "уже запущен",
            // а не "я первый": второй процесс плодить нельзя.
            MessageBox.Show("PowerSwitcher уже запущен (возможно, с правами администратора — ищите иконку в трее).",
                "PowerSwitcher", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return 0;
        }
        catch (System.Threading.AbandonedMutexException ex)
        {
            // Предыдущий владелец упал, не отпустив мьютекс, — владение перешло нам
            m = ex.Mutex;
            createdNew = true;
        }
        catch { createdNew = true; }
        if (!createdNew)
        {
            try { if (m != null) m.Close(); }
            catch { }
            MessageBox.Show("PowerSwitcher уже запущен (ищите иконку в трее).",
                "PowerSwitcher", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return 0;
        }

        try
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            using (MainForm f = new MainForm())
            {
                Application.Run(f);
            }
            return 0;
        }
        finally
        {
            try { if (m != null) m.ReleaseMutex(); }
            catch { }
            try { if (m != null) m.Close(); }
            catch { }
        }
    }

    const int ATTACH_PARENT_PROCESS = -1;
    [DllImport("kernel32.dll")]
    static extern bool AttachConsole(int dwProcessId);
    [DllImport("kernel32.dll")]
    static extern bool AllocConsole();
    [DllImport("kernel32.dll")]
    static extern bool FreeConsole();
}
