# PowerSwitcher autostart via Task Scheduler.
# Run this script as Administrator.
# The task starts at logon with highest privileges, so no UAC prompt appears.
# NOTE: plain ASCII on purpose - Windows PowerShell 5.1 reads a BOM-less
# UTF-8 file as ANSI and non-ASCII text would turn into mojibake.
$exe = Join-Path $PSScriptRoot "PowerSwitcher.exe"
if (-not (Test-Path -LiteralPath $exe)) { Write-Error "Not found: $exe"; exit 1 }

$taskName = "PowerSwitcherAltQ"

# Stop an already running instance (e.g. started manually) before (re)install
Get-Process PowerSwitcher -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue

# Domain-qualified user covers domain and Microsoft accounts too
$user = "$env:USERDOMAIN\$env:USERNAME"
$action = New-ScheduledTaskAction -Execute $exe
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $user
$principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit 0

Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description "PowerSwitcher Alt+Q - power scheme switcher" | Out-Null
Start-ScheduledTask -TaskName $taskName
Write-Host "Done. Task '$taskName' created and started for $user."
Write-Host "Check: Get-ScheduledTask -TaskName $taskName"
