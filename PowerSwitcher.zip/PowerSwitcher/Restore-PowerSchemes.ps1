#Requires -RunAsAdministrator
# Restores your 3 custom power schemes after a Windows reinstall.
# Order by meaning: Ultra-saving -> Balanced -> Ultra-performance.
# Run as Administrator from the folder that contains the "schemes" subfolder.
# Expected layout (keep the whole folder, e.g. on a USB stick):
#   Restore-PowerSchemes.ps1
#   schemes\Ultra-Eco.pow
#   schemes\Balanced.pow
#   schemes\Ultra-Perf.pow
# NOTE: plain ASCII on purpose - Windows PowerShell 5.1 reads a BOM-less
# UTF-8 file as ANSI and non-ASCII text would turn into mojibake.

$ErrorActionPreference = "Stop"
$dir = Join-Path $PSScriptRoot "schemes"

$wanted = @(
    @{ File = "Ultra-Eco.pow";  Guid = "10000000-0000-0000-0000-000000000001" },
    @{ File = "Balanced.pow";   Guid = "20000000-0000-0000-0000-000000000001" },
    @{ File = "Ultra-Perf.pow"; Guid = "30000000-0000-0000-0000-000000000001" }
)
# Day-to-day scheme to activate at the end
$goActive = "20000000-0000-0000-0000-000000000001"

function Get-SchemeGuids {
    $res = @()
    foreach ($line in (powercfg /LIST)) {
        if ($line -match "([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})") {
            $res += $Matches[1].ToLower()
        }
    }
    return $res
}

$before = @(Get-SchemeGuids)

# 1. Import, keeping stable GUIDs when possible
foreach ($w in $wanted) {
    $pow = Join-Path $dir $w.File
    if (-not (Test-Path -LiteralPath $pow)) { throw ("Missing file: " + $pow) }
    powercfg /IMPORT "$pow" $w.Guid | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Write-Host ("GUID import failed for " + $w.File + ", importing with a new GUID...")
        powercfg /IMPORT "$pow" | Out-Null
        if ($LASTEXITCODE -ne 0) { throw ("Import failed: " + $w.File) }
    }
}

$after = @(Get-SchemeGuids)
$added = @($after | Where-Object { $before -notcontains $_ })
$keep = @()
foreach ($w in $wanted) {
    if ($after -contains $w.Guid.ToLower()) { $keep += $w.Guid.ToLower() }
}
$keep = @($keep + $added | Select-Object -Unique)

# 2. Activate day-to-day scheme first (the active one cannot be deleted)
if ($keep -notcontains $goActive.ToLower()) { $goActive = $keep[0] }
powercfg /SETACTIVE $goActive
if ($LASTEXITCODE -ne 0) { throw "Failed to activate $goActive" }

# 3. Delete everything else (inbox Balanced / High performance / Power saver, leftovers)
foreach ($g in $after) {
    if ($keep -notcontains $g) {
        powercfg /DELETE $g | Out-Null
        if ($LASTEXITCODE -ne 0) { Write-Host ("Could not delete " + $g + ", skipping.") }
    }
}

Write-Host "Done. Final schemes:"
powercfg /LIST
